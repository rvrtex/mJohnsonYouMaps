﻿using Windows.UI.Xaml.Controls;

namespace WinRTXamlToolkit.Debugging.Views.PropertyEditors
{
    public sealed partial class DependencyObjectPropertyEditor : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DependencyObjectPropertyEditor"/> class.
        /// </summary>
        public DependencyObjectPropertyEditor()
        {
            this.InitializeComponent();
        }
    }
}

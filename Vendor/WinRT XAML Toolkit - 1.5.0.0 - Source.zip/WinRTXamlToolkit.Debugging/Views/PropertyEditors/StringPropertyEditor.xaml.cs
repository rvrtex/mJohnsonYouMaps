﻿using Windows.UI.Xaml.Controls;

namespace WinRTXamlToolkit.Debugging.Views.PropertyEditors
{
    public sealed partial class StringPropertyEditor : UserControl
    {
        public StringPropertyEditor()
        {
            this.InitializeComponent();
        }
    }
}

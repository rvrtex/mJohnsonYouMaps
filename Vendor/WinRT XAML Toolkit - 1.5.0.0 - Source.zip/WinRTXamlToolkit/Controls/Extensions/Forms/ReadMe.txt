﻿Extensions (attached properties, behaviors, etc.) in this folder are helpful for form filling and include
- validation
- automatic selection of field content on focus
- automatic focus switch to next field when entered text length equals MaxLength
- switching focus to next field
- password value matching value from another field
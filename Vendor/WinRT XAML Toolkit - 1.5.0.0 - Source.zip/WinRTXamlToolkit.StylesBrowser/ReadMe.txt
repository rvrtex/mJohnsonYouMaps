﻿Browser of the full StandardStyles dictionary from Tim Heuer's Blog:
http://timheuer.com/blog/archive/2012/03/05/visualizing-appbar-command-styles-windows-8.aspx

﻿using WinRTXamlToolkit.Sample.Common;

namespace WinRTXamlToolkit.Sample.ViewModels
{
    public class ViewModel : BindableBase
    {
    }
}

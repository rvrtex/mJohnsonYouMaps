﻿// XAML Map Control - http://xamlmapcontrol.codeplex.com/
// Copyright © 2014 Clemens Fischer
// Licensed under the Microsoft Public License (Ms-PL)

namespace MapControl
{
    public partial class MapRectangle
    {
        static MapRectangle()
        {
            geometryScaleTransform.Freeze();
        }
    }
}

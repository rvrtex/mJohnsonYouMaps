The Visual Studio Project for Windows Runtime resides in a separate folder
MapControl/WinRT, because it needs to have its own Themes/Generic.xaml file.
Output is generated to ../bin.
using System.Windows;

namespace SurfaceApplication
{
    public partial class App : Application
    {
    }
}
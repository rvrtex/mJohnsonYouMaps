﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Silverlight/Web Sample Application")]
[assembly: AssemblyDescription("XAML Map Control Silverlight/Web Sample Application")]

[assembly: AssemblyProduct("XAML Map Control")]
[assembly: AssemblyCompany("Clemens Fischer")]
[assembly: AssemblyCopyright("Copyright © 2014 Clemens Fischer")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.11.2")]
[assembly: AssemblyFileVersion("1.11.2")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
